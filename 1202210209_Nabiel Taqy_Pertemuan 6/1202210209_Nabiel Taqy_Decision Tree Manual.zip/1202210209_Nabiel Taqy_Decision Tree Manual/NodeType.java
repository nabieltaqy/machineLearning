public enum NodeType {
    ROOTNODE,
    BRANCH,
    LEAFNODE
}