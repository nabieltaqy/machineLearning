
public enum NodeType {
	ROOTNODE,
	LEAFNODE,
	BRANCH
}
